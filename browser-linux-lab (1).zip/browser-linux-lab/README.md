# Kernel Garden — Browser Linux Lab

A local-first, desktop-style browser environment for running a Linux kernel using [v86](https://github.com/copy/v86), an x86 emulator that uses WebAssembly. There is no remote command-execution backend. The local Vite server is only for serving the app files during development.

## What this prototype includes

- Full browser desktop shell: wallpaper, top panel and clock, app launcher, dock, draggable/minimizable/maximizable windows, and quick settings panel.
- Desktop apps: Terminal, Files, local start-page Browser, System Monitor, Settings, and About.
- Theme and accent controls, responsive layouts, and toast notifications.
- A Linux serial console connected to xterm.js and v86.
- Local asset checks and a service worker that caches the app shell and same-origin assets after they're fetched.

## Requirements

- Node.js 20+ and npm.
- Internet for initial npm install and asset setup (or an already-populated npm cache plus local asset files).
- A modern browser with WebAssembly support.

## Run it

```bash
npm install
npm run setup:assets
npm run dev
```

Open the `http://127.0.0.1:...` URL printed by Vite. Open **Terminal** from the dock or Activities menu, then click **Boot Linux**. You can launch apps from the desktop icons, dock, or Activities menu.

The first setup downloads the v86 WebAssembly runtime/BIOS assets from the installed package or official v86 repository, plus the public Buildroot kernel image from `i.copy.sh`. The downloaded kernel is an upstream demonstration image; it is not a custom distro built for this UI. The exact shell prompt and serial-console behavior depend on that image's kernel configuration.

## Offline use

After setup, keep `node_modules/` and `public/assets/` in place. To use offline, start the local static server while disconnected from the internet. Do not delete the assets. For production hosting, run `npm run build` and serve `dist/` from any static host; there is no backend API. For truly offline use without any network connection, the app bundle, npm dependencies, and guest assets must already be present on disk.

The interface uses system fonts and makes no third-party font requests.

## Desktop UI versus a graphical Linux desktop

The desktop shell is a browser-rendered UI that provides a desktop-like workspace around the emulated Linux serial console. It is not yet a Linux desktop environment (such as XFCE or LXDE) running inside the guest. The Files app contains illustrative sample folders and is not connected to the Linux guest filesystem; the Browser app is a local start page, not a general-purpose web browser. System Monitor displays configured VM settings rather than live host performance.

## Important limitations

- v86 currently targets 32-bit x86 guests; it does not run a modern 64-bit Linux kernel. Check upstream v86 compatibility notes before selecting a guest image.
- This prototype is not a security boundary for untrusted workloads and does not implement Linux namespaces/cgroups as isolated containers. It runs one guest OS inside an emulated machine.
- Browser security prevents a web page from listening on arbitrary local ports or accessing the host filesystem directly. Any file import/export or network bridge must be explicitly designed.
- A hard browser refresh can reset guest RAM. Persistent disks/snapshots are not yet wired into this prototype.
- The upstream demo kernel's console and shell configuration may need adjustment. If boot output appears but no prompt arrives, inspect the serial console and use an image built for v86 with `console=ttyS0` enabled.

## Project layout

```text
src/main.js             Desktop shell, app windows, and v86 serial terminal bridge
src/style.css           Desktop and app-window styling
scripts/setup-assets.mjs Downloads/copies local emulator and Linux assets
public/sw.js             Basic app-shell and local-asset caching
```

## Licensing

This project is a separate prototype. v86 is distributed under the Simplified BSD License; xterm.js packages have their own licenses. The Linux kernel and root filesystem images are separate artifacts and retain their respective licenses. Review upstream licenses before redistributing downloaded assets.
