import { mkdir, copyFile, access, stat } from 'node:fs/promises';
import { createWriteStream } from 'node:fs';
import { pipeline } from 'node:stream/promises';
import { Readable } from 'node:stream';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const assetsDir = path.join(root, 'public', 'assets');
await mkdir(assetsDir, { recursive: true });

async function copyFirstExisting(candidates, destination) {
  for (const candidate of candidates) {
    try { await access(candidate); await copyFile(candidate, path.join(assetsDir, destination)); console.log(`Copied ${destination}`); return true; } catch {}
  }
  return false;
}
async function download(url, destination) {
  const out = path.join(assetsDir, destination);
  console.log(`Downloading ${destination} …`);
  const response = await fetch(url, { redirect: 'follow' });
  if (!response.ok) throw new Error(`Download failed (${response.status}): ${url}`);
  await pipeline(Readable.fromWeb(response.body), createWriteStream(out));
  console.log(`Saved ${destination} (${(await stat(out)).size.toLocaleString()} bytes)`);
}
const v86Root = path.join(root, 'node_modules', 'v86');
const wasmCopied = await copyFirstExisting([
  path.join(v86Root, 'build', 'v86.wasm'),
  path.join(v86Root, 'lib', 'v86.wasm'),
  path.join(v86Root, 'v86.wasm'),
], 'v86.wasm');
if (!wasmCopied) {
  throw new Error('Could not find v86.wasm in node_modules/v86. Inspect the installed v86 package and update scripts/setup-assets.mjs if its layout changed.');
}
const biosCopied = await copyFirstExisting([path.join(v86Root, 'bios', 'seabios.bin')], 'seabios.bin');
const vgaCopied = await copyFirstExisting([path.join(v86Root, 'bios', 'vgabios.bin')], 'vgabios.bin');
if (!biosCopied || !vgaCopied) {
  console.warn('BIOS files are not included in this npm package layout; downloading from the official v86 repository.');
  if (!biosCopied) await download('https://raw.githubusercontent.com/copy/v86/master/bios/seabios.bin', 'seabios.bin');
  if (!vgaCopied) await download('https://raw.githubusercontent.com/copy/v86/master/bios/vgabios.bin', 'vgabios.bin');
}
await download('https://i.copy.sh/buildroot-bzimage68.bin', 'buildroot-bzimage68.bin');
console.log('\nAssets are ready. Run `npm run dev` and open the local URL shown.');
console.log('After the first setup, the app itself does not require a remote execution server. Keep public/assets and node_modules for offline development.');
